﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TopLine : MonoBehaviour
{
    public bool isMove = false;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag.Contains("Fruit"))
        {
            if(other.gameObject.GetComponent<Fruits>().fruitState==FruitState.Collision)
            {
                //GameManager.gameManagerInstance.gameState = GameState.GameOver;
                Invoke("ChangeMoveState", 0.5f);
            }
        }
    }
    void ChangeMoveState()
    {
        isMove = true;
    }
    void CaculateScore()
    {

    }
}
