﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


//默认Ready
//点击开始到鼠标点击控制水果位置，StandBy
//松开鼠标水果跌落，InProgress
//水果跌落碰撞到地板或者其他水果之后，回滚到StandBy
//public enum GameState
//{
//    Ready=0,
//    StandBy=1,
//    InProgress=2,
//    GameOver=3,
//    CalculateScore=4,
//}
public class GameManager : MonoBehaviour
{
    public GameObject[] fruitList;
    public GameObject fruitBornPosition;
    public GameObject startBtn;
    public static GameManager gameManagerInstance;//静态可以直接在别的类使用
    //public GameState gameState;
    public Vector3 combineScale = new Vector3(0,0,0);
    public float totalScore=0.0f;

    public Text textScore;
    public AudioSource combineAudio;
    public AudioSource collisionAudio;

    public Vector3 leftEdge,rightEdge;
    private void Awake()
    {
        gameManagerInstance = this;
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void StartGame()
    {
        Debug.Log("Start");
        CreateFruit();
        //gameState = GameState.StandBy;
        startBtn.SetActive(false);
    }
    public void InvokeCreateFruit(float invokeTime)
    {
        Invoke("CreateFruit", invokeTime);
        
    }
    public void CreateFruit()
    {
        int index = Random.Range(0,5);
        if (fruitList.Length >= index && fruitList[index] != null)
        {
            GameObject fruitObj = fruitList[index];
            var currentFruit=Instantiate(fruitObj, fruitBornPosition.transform.position, fruitObj.transform.rotation);
            currentFruit.GetComponent<Fruits>().fruitState = FruitState.StandBy;
        }
        
    }
    public void CombineNewFruit(FruitType currentFruitType,Vector3 currentPos,Vector3 collisionPos)
    {
        Vector3 centerPos = (currentPos + collisionPos) / 2;
        int index = (int)currentFruitType + 1;
        GameObject combineFruitObj = fruitList[index];
        var combineFruit = Instantiate(combineFruitObj, centerPos, combineFruitObj.transform.rotation);
        combineFruit.GetComponent<Rigidbody2D>().gravityScale = 1.0f;
        combineFruit.GetComponent<Fruits>().fruitState = FruitState.Collision;
        //combineFruit.transform.localScale = combineScale+new Vector3(0.1f,0.1f,0.1f);
        combineAudio.Play();
    }
}
