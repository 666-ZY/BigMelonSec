﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//默认Ready
//待命以及鼠标控制移动时：StandBy
//跌落：Dropping
//碰撞到地板或者其他水果：Collision
public enum FruitType
{
    One=0,
    Two=1,
    Three=2,
    Four=3,
    Five=4,
    Six=5,
    Seven=6,
    Eight=7,
    Nine=8,
    Ten=9,
    Eleven=10,
    
}
public enum FruitState
{
    Ready=0,
    StandBy=1,
    Dropping=2,
    Collision=3,
}
public class Fruits : MonoBehaviour
{
    public FruitType fruitType = FruitType.One;
    public FruitState fruitState = FruitState.Ready;
    private bool isMove = false;

    public float limit_x = 2f;
    public float scaleSpeed = 0.1f;

    public float fruitScore = 1.0f;
    public Vector3 fruitScale;

    

    private void Awake()
    {
        
    }
    // Start is called before the first frame update
    void Start()
    {
        this.gameObject.GetComponent<Transform>().localScale = fruitScale;
    }

    // Update is called once per frame
    void Update()
    {
       
        //游戏状态Standby&&水果状态StandBy，可以鼠标点击控制移动，以及松开鼠标跌落
        if(fruitState==FruitState.StandBy)
        {
            //Vector3 pos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            if (Input.GetMouseButtonDown(0))
            {
                isMove = true;
            }

            if (Input.GetMouseButtonUp(0))
            {
                isMove = false;
                this.gameObject.GetComponent<Rigidbody2D>().gravityScale = 1.0f;
                fruitState = FruitState.Dropping;
                //GameManager.gameManagerInstance.gameState = GameState.InProgress;
                //创建新水果
                GameManager.gameManagerInstance.InvokeCreateFruit(1.5f);
            }

            if (isMove)
            {
                Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                this.gameObject.GetComponent<Transform>().position = new Vector3(mousePos.x, this.gameObject.GetComponent<Transform>().position.y, this.gameObject.GetComponent<Transform>().position.z);
            }

            if (this.transform.position.x > -limit_x)
            {
                this.transform.position = new Vector3(-limit_x, this.transform.position.y, this.transform.position.z);
            }
            if (this.transform.position.x < limit_x)
            {
                this.transform.position = new Vector3(limit_x, this.transform.position.y, this.transform.position.z);
            }

            ////尺寸恢复
            //if (this.transform.localScale.x < originalScale.x)
            //{
            //    this.transform.localScale += new Vector3(1, 1, 1) * scaleSpeed;
            //}
            //if (this.transform.localScale.x > originalScale.x)
            //{
            //    this.transform.localScale = originalScale;
            //}

        }
    }


    private void OnCollisionEnter2D(Collision2D collision)
    {
       
        if (fruitState == FruitState.Dropping)
        {
            Debug.Log("collision");
            GameManager.gameManagerInstance.collisionAudio.Play();
            if (collision.gameObject.tag.Contains("Floor"))
            {
                //GameManager.gameManagerInstance.gameState = GameState.StandBy;
                fruitState = FruitState.Collision;
            }
            if (collision.gameObject.tag.Contains("Fruit"))
            {
                //GameManager.gameManagerInstance.gameState = GameState.StandBy;
                fruitState = FruitState.Collision;
            }
        }
       

        if((int)fruitState>=(int)FruitState.Dropping)//可以合成
        {
            
            if (collision.gameObject.tag.Contains("Fruit"))
            {
                
                if (fruitType == collision.gameObject.GetComponent<Fruits>().fruitType && fruitType!=FruitType.Eleven)
                {
                    float thisPosxy = this.transform.position.x + this.transform.position.y;
                    float collisionPosxy = collision.transform.position.x + collision.transform.position.y;
                    if (thisPosxy > collisionPosxy)
                    {
                        GameManager.gameManagerInstance.CombineNewFruit(fruitType, this.transform.position, collision.transform.position);
                        GameManager.gameManagerInstance.totalScore += fruitScore;
                        GameManager.gameManagerInstance.textScore.text = GameManager.gameManagerInstance.totalScore.ToString();
                        Destroy(this.gameObject);

                        Destroy(collision.gameObject);

                        Fruits[] fruits = FindObjectsOfType<Fruits>();
                        foreach(var item in fruits)
                        {
                            if(item.tag.Contains("Eleven"))
                            {
                                GameManager.gameManagerInstance.textScore.text = "Game Success";
                                Application.Quit();
                            }
                        }
                    }
                    
                }
            }
        }
    }

}
